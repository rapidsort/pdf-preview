=== RSV PDF Preview ===

Contributors: Rapid Sort, sumaravi
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=DRYFKH2KWYFZA
Tags: PDF, PDF Preview, short version of PDF, genarate PDF, custom PDF
Requires at least: 3.0
Requires PHP: 5.6
Tested up to: 5.3.1
Stable tag: 1.0
License: GPLv2 or later

RSV PDF Preview is use to show sample preview of any pdf without creating new short version of pdf document.

== Description ==

RSV PDF Preview plugin for displaying PDF files as a sample with out any additinal work. 

This Plugin is based on <a href="https://mozilla.github.io/pdf.js/" target="_blank">PDF JS</a>.

== Installation ==

1. Upload the <strong>rsv-pdf-preview</strong> folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the shortcode <strong>[rsv_pdf_preview pages='4' url='pdfFileURL.pdf' show-custom-page='true' title='New PDF' custom-message-title='custom message title' custom-message-content='custom message content']</strong> in the content area of a page or post where you want the PDF Preview to appear.


== Frequently Asked Questions ==

= How do I insert the RSV PDF Preview? =
You can insert the RSV PDF Preview by pasting the shortcode `[rsv_pdf_preview url='pdfFileURL.pdf']` into the content area of a page or post. To customize your PDF Preview, there are optional attributes that can be used with the shortcode.


== Screenshots ==

1. No Screenshoots

== Changelog ==

= 1.0 =
* RSV PDF Preview WordPress plugin.


== Upgrade Notice ==
This is the first version.

